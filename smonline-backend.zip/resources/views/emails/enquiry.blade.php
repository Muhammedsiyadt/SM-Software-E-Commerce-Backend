<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<meta http-equiv="Content-Type" content="text/html charset=UTF-8" />
<html lang="en">

  <head></head>
  <div id="__react-email-preview" style="display:none;overflow:hidden;line-height:1px;opacity:0;max-height:0;max-width:0">Yelp recent login<div></div>
  </div>

  <body style="background-color:#fff;font-family:-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Oxygen-Sans,Ubuntu,Cantarell,&quot;Helvetica Neue&quot;,sans-serif">
    <table align="center" role="presentation" cellSpacing="0" cellPadding="0" border="0" width="100%" style="max-width:37.5em">
      <tr style="width:100%">
        <td>

          <table style="border:1px solid rgb(0,0,0, 0.1);border-radius:3px;overflow:hidden" align="center" border="0" cellPadding="0" cellSpacing="0" role="presentation" width="100%">
            <tbody>
              <tr>
                <td>
                    <br>
                    <svg version="1.0" xmlns="http://www.w3.org/2000/svg"
                    width="120px" height="50px" viewBox="0 0 544.000000 438.000000"
                    preserveAspectRatio="xMidYMid meet">

                   <g transform="translate(0.000000,438.000000) scale(0.100000,-0.100000)"
                   fill="#000000" stroke="none">
                   <path d="M4225 4319 c-174 -18 -304 -63 -469 -163 -39 -23 -79 -45 -88 -49
                   -11 -4 -54 19 -128 68 -63 42 -139 83 -176 95 -133 45 -525 65 -681 35 -331
                   -63 -545 -224 -646 -487 l-32 -83 0 -1160 0 -1160 341 -3 c308 -2 343 -1 355
                   14 12 14 15 199 19 1103 5 1003 7 1090 23 1138 23 69 72 131 132 168 44 27 56
                   30 134 30 169 0 235 -68 261 -265 5 -44 10 -502 10 -1117 0 -933 2 -1043 16
                   -1057 13 -14 60 -16 358 -16 317 0 344 1 359 18 15 16 17 118 20 1082 2 920 5
                   1073 18 1120 45 159 139 239 281 240 91 0 179 -44 220 -110 60 -98 58 -63 58
                   -1247 l0 -1083 27 -11 c33 -12 702 -8 722 5 12 8 13 173 7 1120 -8 1178 -9
                   1204 -56 1328 -28 73 -109 178 -184 239 -69 57 -231 139 -321 163 -168 44
                   -410 63 -580 45z"/>
                   <path d="M1241 4169 c-51 -10 -308 -156 -516 -294 -297 -197 -469 -375 -572
                   -591 -41 -86 -45 -141 -18 -225 45 -140 54 -150 475 -569 439 -437 437 -434
                   428 -547 -12 -165 -166 -351 -445 -540 -62 -42 -113 -80 -113 -85 0 -5 145 -8
                   358 -6 l357 3 65 34 c356 185 569 503 506 751 -9 35 -29 85 -43 110 -15 24
                   -135 156 -268 291 -247 252 -434 458 -479 526 -31 47 -42 114 -27 170 27 99
                   175 274 353 418 119 95 371 263 627 415 121 72 223 135 226 141 8 12 -852 10
                   -914 -2z"/>
                   <path d="M763 1139 c-124 -21 -222 -81 -266 -163 -21 -39 -22 -54 -25 -334 -4
                   -345 1 -380 60 -447 74 -83 199 -125 376 -125 194 1 338 64 400 175 25 44 31
                   619 8 699 -29 98 -136 171 -288 196 -74 12 -191 11 -265 -1z m181 -181 c14
                   -19 16 -70 16 -348 0 -360 -2 -370 -60 -370 -59 0 -61 11 -58 380 3 315 4 332
                   22 346 29 21 63 17 80 -8z"/>
                   <path d="M1480 610 l0 -520 155 0 155 0 1 233 1 232 18 -40 c11 -22 54 -127
                   97 -232 l78 -193 163 0 162 0 0 520 0 520 -155 0 -155 0 -2 -230 -3 -229 -101
                   227 -101 227 -157 3 -156 3 0 -521z"/>
                   <path d="M2470 610 l0 -520 300 0 300 0 0 100 0 100 -115 0 -115 0 0 420 0
                   420 -185 0 -185 0 0 -520z"/>
                   <path d="M3170 610 l0 -520 185 0 185 0 0 520 0 520 -185 0 -185 0 0 -520z"/>
                   <path d="M3700 610 l0 -520 155 0 155 0 1 233 1 232 18 -40 c11 -22 54 -127
                   97 -232 l78 -193 163 0 162 0 0 520 0 520 -155 0 -155 0 -2 -230 -3 -229 -101
                   227 -101 227 -157 3 -156 3 0 -521z"/>
                   <path d="M4690 610 l0 -520 320 0 320 0 0 100 0 100 -135 0 -135 0 0 120 0
                   120 115 0 115 0 0 95 0 95 -115 0 -115 0 0 105 0 105 125 0 125 0 0 100 0 100
                   -310 0 -310 0 0 -520z"/>
                   </g>
                   </svg>

                  <table width="100%" style="padding:20px 40px;padding-bottom:0" align="center" role="presentation" cellSpacing="0" cellPadding="0" border="0">
                    <tbody style="width:100%">
                      <tr style="width:100%">
                        <td>

                          <h1 style="font-size:32px;font-weight:bold;text-align:center">Hi Admin</h1>
                          <h2 style="font-size:26px;font-weight:bold;text-align:center">You have a new enquiry</h2>
                          <p style="font-size:16px;line-height:24px;margin:16px 0"><b>Name: </b> {{$contact->name}}</p>
                          <p style="font-size:16px;line-height:24px;margin:16px 0;margin-top:-5px"><b>Email: </b> {{$contact->email}}</p>
                          <p style="font-size:16px;line-height:24px;margin:16px 0;margin-top:-5px"><b>Phone: </b>{{$contact->phone}}</p>
                          <p style="font-size:16px;line-height:24px;margin:16px 0;margin-top:-5px"><b>Subject: </b>{{$contact->subject}}</p>
                          <p style="font-size:16px;line-height:24px;margin:16px 0;margin-top:-5px"><b>Message: </b>{{$contact->message}}</p>

                        </td>
                      </tr>
                    </tbody>
                  </table>

                </td>
              </tr>
            </tbody>
          </table>
          <table style="padding:45px 0 0 0" align="center" border="0" cellPadding="0" cellSpacing="0" role="presentation" width="100%">
            <tbody>
              <tr>
                <td><img src="https://react-email-demo-ijnnx5hul-resend.vercel.app/static/yelp-footer.png" width="620"
                    style="display:block;outline:none;border:none;text-decoration:none" /></td>
              </tr>
            </tbody>
          </table>
        </td>
      </tr>
    </table>
  </body>

</html>
