


<link rel="icon" type="image/png" sizes="16x16" href="{{asset('assets/images/favicon.png')}}">
<link href="{{asset('assets/vendor/pg-calendar/css/pignose.calendar.min.css')}}" rel="stylesheet">
<link href="{{asset('assets/vendor/chartist/css/chartist.min.css')}}" rel="stylesheet">
<link href="{{asset('assets/css/style.css')}}" rel="stylesheet">
<link href="{{asset('assets/css/theme.css')}}" rel="stylesheet">
<link href="{{asset('assets/css/tagged.css')}} " rel="stylesheet">
<link href="{{asset('assets/vendor/apexcharts/apex_chart.css')}} " rel="stylesheet">
<link href="{{asset('assets/css/datatable.css')}} " rel="stylesheet">
