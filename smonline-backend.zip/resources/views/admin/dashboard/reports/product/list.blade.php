@extends('admin.dashboard.layouts.master')

@section('styles')

@endsection

@section('admin-content')
    <div class="container-fluid">



    </div>
@endsection
@section('scripts')

<script>
</script>
@endsection
