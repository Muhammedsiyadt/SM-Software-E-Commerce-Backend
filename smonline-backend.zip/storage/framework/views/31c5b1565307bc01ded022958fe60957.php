<?php
use App\Models\Menu;
    $menu_item = Menu::where('is_active', true)->get();
    $usr = Auth::guard('admin')->user();
    // dd(Auth::guard('admin')->user());

?>
<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Admin'); ?></title>

    

    <?php echo $__env->make('admin.dashboard.layouts.partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body>
    
    <div id="main-wrapper">


        <?php echo $__env->make('admin.dashboard.layouts.commons.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.dashboard.layouts.commons.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="content-body">
        <?php echo $__env->yieldContent('admin-content'); ?>
        </div>

        <?php echo $__env->make('admin.dashboard.layouts.commons.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo $__env->make('admin.dashboard.layouts.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH E:\AthulVinod\sm soft new 1\smonline-backend\resources\views/admin/dashboard/layouts/master.blade.php ENDPATH**/ ?>