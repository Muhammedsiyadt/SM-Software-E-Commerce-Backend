<!doctype html>
<html class="h-100" lang="en">

<head>

    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Admin - Login'); ?></title>
    <meta content="" name="description" />
    <meta content="" name="author" />



    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/images/favicon.png')); ?>">
    <link href="<?php echo e(asset('assets/css/core.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">


    <?php echo $__env->yieldContent('styles'); ?>

</head>

<body  class="h-100">

<?php echo $__env->yieldContent('auth-content'); ?>



<script src="<?php echo e(asset('assets/vendor/global/global.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/quixnav-init.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.min.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH E:\AthulVinod\sm soft new 1\smonline-backend\resources\views/admin/auth/layout.blade.php ENDPATH**/ ?>