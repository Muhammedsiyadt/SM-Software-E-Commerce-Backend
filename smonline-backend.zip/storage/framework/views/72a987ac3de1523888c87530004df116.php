




<?php

//  $usr=Auth::guard('admin')->user();
// dd($usr);
?>



    <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="brand-logo">
                
                
                <img class="brand-title" src="<?php echo e(asset('assets/images/sm-online.png')); ?>" alt="">
                
            </a>

            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->

        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="header-left">
                            
                        </div>

                        <ul class="navbar-nav header-right">
                            <li class="nav-item dropdown header-profile">
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                    <i class="mdi mdi-account"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    

                                    <?php if($usr&&$usr->can('profile.view')): ?>
                                    <a href="<?php echo e(route('admin.profile')); ?>" class="dropdown-item">
                                        <i class="icon-user"></i>
                                        <span class="ml-2">Profile </span>
                                    </a>

                                    <?php endif; ?>
                                    



                                    <a class="dropdown-item" href="<?php echo e(route('admin.logout.submit')); ?>"
                                    onclick="event.preventDefault();
                                                  document.getElementById('admin-logout-form').submit();">
                                        <i class="icon-key"></i>
                                        <span class="ml-2">Logout </span>
                                    </a>

                                    <form id="admin-logout-form" action="<?php echo e(route('admin.logout.submit')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>




                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
<?php /**PATH E:\AthulVinod\sm soft new 1\smonline-backend\resources\views/admin/dashboard/layouts/commons/header.blade.php ENDPATH**/ ?>