<?php $__env->startSection('styles'); ?>
   <style>
     .profile{
        width:90px!important;
    }
    .error{
        color: red;
    }
   </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="container-fluid">
        <div class="row page-titles mx-0">

            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>Admin Users</h4>
                    <p class="mb-0">Manage and control user access and permissions within the system.</p>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)">Admin User</a></li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Manage Admins</h4>
                        <div class="d-sm-flex justify-content-between">
                            <a href="<?php echo e(route('admin.admins.create')); ?>" class="btn-sm btn-success text-white">Add Admin</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table header-border table-responsive-sm">
                                    <thead>
                                        <tr>
                                            <th class="font-weight-bold text-dark">#</th>
                                            <th class="font-weight-bold text-dark">Name</th>
                                            <th class="font-weight-bold text-dark">Username</th>
                                            <th class="font-weight-bold text-dark">Email</th>
                                            <th class="font-weight-bold text-dark">Roles</th>
                                            <th class="font-weight-bold text-dark">Action</th>

                                        </tr>
                                    </thead>
                                    <tbody>

                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($admin->id); ?></td>
                                                <td><?php echo e($admin->name); ?></td>
                                                <td><?php echo e($admin->username); ?></td>
                                                <td><?php echo e($admin->email); ?></td>
                                                <td>
                                                    <ul>
                                                        <?php $__currentLoopData = $admin->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li>
                                                            <?php echo e($role->name); ?>

                                                        </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </td>

                                                <td>
                                                    <?php if(Auth::guard('admin')->user()->can('admin.edit')): ?>
                                                        <a class="" href="<?php echo e(route('admin.admins.edit', $admin->id)); ?>">
                                                            <i class="fa fa-edit text-warning btn"></i>
                                                        </a>
                                                    <?php endif; ?>

                                                    <?php if(Auth::guard('admin')->user()->can('admin.delete')): ?>
                                                    <a class="" href="<?php echo e(route('admin.admins.destroy', $admin->id)); ?>"
                                                    onclick="event.preventDefault(); document.getElementById('delete-form-<?php echo e($admin->id); ?>').submit();">
                                                    <i class="fa fa-trash text-danger btn"></i>
                                                    </a>
                                                    <form id="delete-form-<?php echo e($admin->id); ?>" action="<?php echo e(route('admin.admins.destroy', $admin->id)); ?>" method="POST" style="display: none;">
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php echo csrf_field(); ?>
                                                    </form>
                                                    <?php endif; ?>
                                                </td>


                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                            <?php endif; ?>
                                        </tbody>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>


</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\AthulVinod\sm soft new 1\smonline-backend\resources\views/admin/dashboard/usermanagement/admins.blade.php ENDPATH**/ ?>