


<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/images/favicon.png')); ?>">
<link href="<?php echo e(asset('assets/vendor/pg-calendar/css/pignose.calendar.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/vendor/chartist/css/chartist.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/css/theme.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/css/tagged.css')); ?> " rel="stylesheet">
<link href="<?php echo e(asset('assets/vendor/apexcharts/apex_chart.css')); ?> " rel="stylesheet">
<link href="<?php echo e(asset('assets/css/datatable.css')); ?> " rel="stylesheet">
<?php /**PATH E:\AthulVinod\sm soft new 1\smonline-backend\resources\views/admin/dashboard/layouts/partials/styles.blade.php ENDPATH**/ ?>