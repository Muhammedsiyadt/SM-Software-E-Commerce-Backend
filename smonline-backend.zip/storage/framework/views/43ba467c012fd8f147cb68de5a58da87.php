<div class="footer">
    <div class="copyright">
        <p> Copyright  &copy; <span id="year"></span> <?php echo e(config('app.name')); ?>, All Rights Reserved. Developed by
            <a href=" <?php echo e(config('app.author_url')); ?>" target="_blank"> <?php echo e(config('app.author')); ?></a></p>


    </div>
</div>


<script>
    let year = document.getElementById('year');
    let currentYear = new Date().getFullYear();
    year.innerHTML = currentYear;
</script>
<?php /**PATH E:\AthulVinod\sm soft new 1\smonline-backend\resources\views/admin/dashboard/layouts/commons/footer.blade.php ENDPATH**/ ?>