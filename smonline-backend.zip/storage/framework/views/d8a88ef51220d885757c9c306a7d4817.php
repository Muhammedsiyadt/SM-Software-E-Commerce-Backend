<?php
    // Dynamic Area
    $usr = auth('admin')->user();
    // dd($usr);
?>


<div class="quixnav">
    <div class="quixnav-scroll">
        <ul class="metismenu" id="menu">
            <li class="nav-label first">Admin</li>
            




            <?php if($usr&&$usr->can('dashboard.view')): ?>
                <li><a href="<?php echo e(route('admin.dashboard')); ?>" aria-expanded="false"><i class="icon icon-globe-2"></i><span
                            class="nav-text">Home</span></a></li>
            <?php endif; ?>

            <?php if(
                $usr&&$usr->can('role.create') ||
                    $usr&&$usr->can('role.view') ||
                    $usr&&$usr->can('role.edit') ||
                    $usr&&$usr->can('role.delete') ||
                    $usr&&$usr->can('admin.create') ||
                    $usr&&$usr->can('admin.view') ||
                    $usr&&$usr->can('admin.edit') ||
                    $usr&&$usr->can('admin.delete')): ?>
                <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i
                            class="icon icon-app-store"></i><span class="nav-text">User Management</span></a>
                    <ul aria-expanded="false">
                        <?php if($usr&&$usr->can('role.view')): ?>
                            <li><a href="<?php echo e(route('admin.roles.index')); ?>">Role</a></li>
                        <?php endif; ?>
                        <?php if($usr&&$usr->can('admin.view')): ?>
                            <li><a href="<?php echo e(route('admin.admins.index')); ?>">Admin</a></li>
                        <?php endif; ?>

                    </ul>
                </li>

            <?php endif; ?>


            <li class="nav-label">E-Commerce</li>


            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
                    <i class="fa fa-th"></i>
                    <span class="nav-text">Products</span></a>
                <ul aria-expanded="false">

                    <?php if($usr&&$usr->can('brand.view')): ?>
                        <li><a href="<?php echo e(route('admin.brands.index')); ?>">Brands</a></li>
                    <?php endif; ?>

                    <?php if($usr&&$usr->can('category.view')): ?>
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Categories</a>
                            <ul aria-expanded="false">
                                <li><a href="<?php echo e(route('admin.maincategories.index')); ?>">Main Category</a></li>
                                

                            </ul>
                        </li>
                    <?php endif; ?>

                    <?php if($usr&&$usr->can('unit.view')): ?>
                        <li><a href="<?php echo e(route('admin.units.index')); ?>">Units</a></li>
                    <?php endif; ?>
                    <?php if($usr&&$usr->can('productTag.view')): ?>
                        <li><a href="<?php echo e(route('admin.productTags.index')); ?>">Products Tags</a></li>
                    <?php endif; ?>
                    <?php if($usr&&$usr->can('productCondition.view')): ?>
                        <li><a href="<?php echo e(route('admin.productConditions.index')); ?>">Product Condition</a></li>
                    <?php endif; ?>
                    <?php if($usr&&$usr->can('product.view')): ?>
                        <li><a href="<?php echo e(route('admin.products.index')); ?>">All Products</a></li>
                    <?php endif; ?>
                    <?php if($usr&&$usr->can('product.create')): ?>
                        <li><a href="<?php echo e(route('admin.products.create')); ?>">Add New Product</a></li>
                    <?php endif; ?>
                    <?php if($usr&&$usr->can('voucher.view')): ?>
                        <li><a href="<?php echo e(route('admin.vouchers.index')); ?>">Voucher</a></li>
                    <?php endif; ?>
                </ul>
            </li>


            <?php if($usr&&$usr->can('dashboard.view')): ?>
            <li><a href="<?php echo e(route('admin.customers.index')); ?>" aria-expanded="false"><i class="icon icon-users-mm-2"></i><span
                        class="nav-text">Customers</span></a></li>
            <?php endif; ?>


            


            <?php if($usr&&$usr->can('order.view')): ?>
            <li>
                <a href="<?php echo e(route('admin.orders.index')); ?>" aria-expanded="false">
                    <i class="icon icon-cart-simple"></i>
                    <span class="nav-text">Orders</span>
                </a>
            </li>
            <?php endif; ?>

            <?php if($usr&&$usr->can('enquiry.view')): ?>
            <li>
                <a href="<?php echo e(route('admin.enquiry.index')); ?>" aria-expanded="false">
                    <i class="icon icon-phone-2"></i>
                    <span class="nav-text">Enquiry</span>
                </a>
            </li>
            <?php endif; ?>



            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
                <i class="fa fa-bars"></i>
                <span class="nav-text">Reports</span></a>
            <ul aria-expanded="false">
                

                <?php if($usr&&$usr->can('unit.view')): ?>
                <li><a href="<?php echo e(route('admin.report.sales')); ?>">Sales Report</a></li>
                <?php endif; ?>
                <?php if($usr&&$usr->can('unit.view')): ?>
                <li><a href="<?php echo e(route('admin.report.stock')); ?>">Stock Report</a></li>
                <?php endif; ?>


            </ul>


































            





            

            
            

            
            




            

        </ul>
    </div>
</div>
<?php /**PATH E:\AthulVinod\sm soft new 1\smonline-backend\resources\views/admin/dashboard/layouts/commons/sidebar.blade.php ENDPATH**/ ?>