<?php $__env->startSection('styles'); ?>
   <style>
     .profile{
        width:90px!important;
    }
    .error{
        color: red;
    }
   </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="container-fluid">
        <div class="row page-titles mx-0">

            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>All Categories</h4>
                    <p class="mb-0">View and manage all categories available on your platform or website.</p>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)">Categories</a></li>
                </ol>
            </div>
        </div>
        <div class="row">

            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Create Main Category</h4>
                        <div class="d-sm-flex justify-content-between">
                            <a href="<?php echo e(route('admin.maincategories.index')); ?>" class="btn-sm btn-success text-white">Main Category</a>
                        </div>
                    </div>
                    <div class="card-body">
                        

                        <div class="col-lg-8">

                            <form action="<?php echo e(route('admin.maincategories.store')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <div class="form-row mb-20">
                                    <div class="col-sm-4">
                                        <label class="font-14 bold black">Name </label>
                                    </div>
                                    <div class="col-sm-8">
                                        <input type="text" name="name" class="form-control"  value=""

                                            placeholder="Type here">
                                    </div>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>






                                <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save</button>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>


</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\AthulVinod\sm soft new 1\smonline-backend\resources\views/admin/dashboard/category/mainCreate.blade.php ENDPATH**/ ?>