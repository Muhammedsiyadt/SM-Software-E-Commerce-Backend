<?php $__env->startSection('styles'); ?>
    <style>
        .card-img {
            width: 100px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="container-fluid">
        <div class="row page-titles mx-0">

            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>All Orders</h4>
                    <p class="mb-0">View and manage all orders received through your platform or website.</p>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)">Orders</a></li>
                </ol>
            </div>


        </div>

        <?php if(Session::has('success')): ?>
            <div class="alert alert-success text-white  alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger text-white  alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('error')); ?>

            </div>
        <?php endif; ?>


        <div class="row">
            <div class="col-lg-12">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="mb-5 d-flex align-items-center justify-content-between">
                            <span>Order No : <a href="#"> <?php echo e($orders->details[0]->order->order_number); ?></a></span>
                            <span class="badge badge-info">

                                <?php echo e($orders->details[0]->order->status); ?>

                            </span>
                        </div>
                        <div class="row mb-5 g-4">
                            <div class="col-md-3 col-sm-6">
                                <p class="fw-bold">Order Created at</p>
                                <?php echo e($orders->details[0]->order->created_at->format('d-m-Y')); ?>

                            </div>
                            <div class="col-md-3 col-sm-6">
                                <p class="fw-bold">Name</p>
                                <?php echo e($orders->details[0]->order->user->name); ?>

                            </div>
                            <div class="col-md-3 col-sm-6">
                                <p class="fw-bold">Email</p>
                                <?php echo e($orders->details[0]->order->user->email); ?>

                            </div>
                            <div class="col-md-3 col-sm-6">
                                <p class="fw-bold">Contact No</p>
                                <?php echo e($orders->details[0]->order->user->phone); ?>

                            </div>
                        </div>
                        <div class="row g-4">

                            <?php $__empty_1 = true; $__currentLoopData = $orders->details[0]->order->user->address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $userAddress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-3 col-sm-12">
                                    <div class="card">
                                        <div class="card-body d-flex flex-column gap-1">
                                            <div class="d-flex justify-content-between">
                                                <h5 class="mb-0">Address <?php echo e($key + 1); ?></h5>
                                                
                                            </div>
                                            <div class="mt-2"><?php echo e($userAddress->address); ?></div>
                                            <div class="mt-2"><?php echo e($userAddress->locality); ?></div>
                                            <div class="mt-2">
                                                <?php echo e($userAddress->city); ?>,
                                                <?php echo e($userAddress->landmark); ?>,
                                                <?php echo e($userAddress->state->name); ?>,
                                                <?php echo e($userAddress->phone_2); ?>,

                                            </div>
                                            <div>
                                                <i class="bi bi-telephone me-2"></i> <?php echo e($userAddress->phone_1); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>

                            
                        </div>
                    </div>
                </div>
            </div>



        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Order Details</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">


                            <form action="<?php echo e(route('admin.orders.update', $orders->details[0]->order->id)); ?>"
                                method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <table class="table header-border table-responsive-sm">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>
                                                <input type="checkbox" id="select-all">
                                            </th>
                                            <th>Order Item Status</th>
                                            <th>Image</th>
                                            <th>Item</th>
                                            <th>Item Stock</th>
                                            <th>Quantity</th>
                                            <th>Unit Price</th>
                                            <th>Sub Total</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $orders->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td>
                                                    <input type="checkbox" name="selectedOrderIds[]" value="<?php echo e($orderDetail->id); ?>">
                                                    <input type="hidden" name="hiddent_ids[<?php echo e($orderDetail->id); ?>]" value="<?php echo e($orderDetail->id); ?>">
                                                </td>                                                
                                                <td>
                                                    <select name="delivery_statuses[<?php echo e($orderDetail->id); ?>]"
                                                        class="form-control">
                                                        <option value="pending"
                                                            <?php echo e($orderDetail->status == 'pending' ? 'selected' : ''); ?>>
                                                            Pending</option>
                                                        <option value="processing"
                                                            <?php echo e($orderDetail->status == 'processing' ? 'selected' : ''); ?>>
                                                            Processing</option>
                                                        <option value="completed"
                                                            <?php echo e($orderDetail->status == 'completed' ? 'selected' : ''); ?>>
                                                            Completed</option>
                                                        <option value="cancelled"
                                                            <?php echo e($orderDetail->status == 'cancelled' ? 'selected' : ''); ?>>
                                                            Cancelled</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <img src="<?php echo e(asset('storage/uploads/product/thumbnail/')); ?>/<?php echo e($orderDetail->product->thumbnail); ?>"
                                                        style="width: 100px" alt="<?php echo e($orderDetail->product->name); ?>">
                                                </td>
                                                <td>
                                                    <?php echo e(Str::limit($orderDetail->product->name, 50)); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($orderDetail->product->stock); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($orderDetail->product_qty); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($orderDetail->product->unit_price); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($orderDetail->sub_total); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </form>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var selectAllCheckbox = document.getElementById("select-all");
            var checkboxes = document.querySelectorAll('input[name="selectedOrderIds[]"]');

            selectAllCheckbox.addEventListener("change", function() {
                checkboxes.forEach(function(checkbox) {
                    checkbox.checked = selectAllCheckbox.checked;
                });
            });

            checkboxes.forEach(function(checkbox) {
                checkbox.addEventListener("change", function() {
                    var allChecked = true;
                    checkboxes.forEach(function(checkbox) {
                        if (!checkbox.checked) {
                            allChecked = false;
                        }
                    });
                    selectAllCheckbox.checked = allChecked;
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\AthulVinod\sm soft new 1\smonline-backend\resources\views/admin/dashboard/orders/edit.blade.php ENDPATH**/ ?>